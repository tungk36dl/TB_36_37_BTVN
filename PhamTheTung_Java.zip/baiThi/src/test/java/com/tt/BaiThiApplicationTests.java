package com.tt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaiThiApplicationTests {

    @Test
    void contextLoads() {
    }

}
