package com.tt.dto;


import lombok.Data;

@Data
public class DepartmentDto {

    private Integer id;

    private String departmentName;

    private Integer numPeople;
}
