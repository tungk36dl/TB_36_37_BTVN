package com.tt.sevice;


import org.springframework.stereotype.Service;

@Service
public interface AccountService {
}
